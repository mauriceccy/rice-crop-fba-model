import scobra

m=scobra.model()
m;